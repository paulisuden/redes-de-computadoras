
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="style.css">
    <title>Pagina Web TP6</title>
</head>
<body>
    <div class="logo">
        <img src="./imagenes/logoUncuyo.jfif" alt="logo Uncuyo">
    </div>
    <div class="main">
        <h1>Elija su equipo favorito</h1>
        <form action="verificar.php" method="POST" onsubmit="return clickhere()">
            <p>Ingrese su email:</p>
            <input id="mail" type="email" name="email" required>
            <div class="equipos">
                <input type="radio" name="equipo" value="Boca Juniors" id="boca" required> 
                <label for="boca">Boca Juniors <img class="boca" src="./imagenes/boca.png" alt="logo boca"></label><br>
                <input type="radio" name="equipo" value="River Plate" id="river" required> 
                <label for="river">River Plate <img class="river" src="./imagenes/river.png" alt="logo river"></label><br>
                <input type="radio" name="equipo" value="San Lorenzo" id="sanlorenzo" required> 
                <label for="sanlorenzo">San Lorenzo <img class="sanLorenzo" src="./imagenes/san lorenzo.png" alt="logo san lorenzo"></label><br>
                <input type="radio" name="equipo" value="Racing" id="racing" required> 
                <label for="racing">Racing <img class="racing" src="./imagenes/racing.png" alt="logo racing"></label><br>
                <input type="radio" name="equipo" value="Independiente" id="independiente" required> 
                <label for="independiente">Independiente <img class="independiente" src="./imagenes/independiente.png" alt="logo independiente"></label><br>
                <input type="radio" name="equipo" value="Otro" id="otro" required> 
                <label for="otro">Otro</label><br>
            </div>
            <button type="submit">Enviar</button> 
        </form>
        <p id="boton"></p>
    </div>

    <script src="script.js"></script>
</body>
</html>
