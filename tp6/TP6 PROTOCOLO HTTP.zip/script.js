function clickhere(){  /* funcion que va a verificar que el mail ingresado es correcto */ 
    let val = document.getElementById("mail").value; 
    let num = val.length;
    let text;
    let regex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/; /* formato correcto de un mail */
    let equipoSeleccionado = document.querySelector('input[name="equipo"]:checked');

    
    if (!equipoSeleccionado){
        text = "Seleccione un equipo";
    } else if (num == 0) {
        text = "Ingrese el mail";
    } else if (num < 7 || !regex.test(val)){ /* verifico el tamaño y el formato*/
        text = "Correo ingresado es incorrecto"
    }  else { 
        text = "Enviado";
        return true
    }

    document.getElementById("boton").innerHTML = text; /* lo que devuelvo por pantalla */
    return false
}
