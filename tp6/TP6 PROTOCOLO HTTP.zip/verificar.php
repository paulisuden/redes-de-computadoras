<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST["email"];
    
    $equipo = $_POST["equipo"];
    
    $statsFile = "estadisticas.txt";
    $emailExists = false;

    // Verificar si el archivo existe y leer su contenido
    if (file_exists("registro.txt")) {
    	$file = fopen("registro.txt", "r");
    
	// Verificar si el email ya está registrado
	while (!feof($file)) {
		$line = trim(fgets($file)); // Lee una línea del archivo y elimina los espacios en blanco
		//echo $line . "<br>"; // Imprime la línea leída (solo para propósitos de depuración)
		if ($line == $email) {
		    $emailExists = true;
		    echo "true"; // Imprime "true" si el email existe (solo para propósitos de depuración)
		    break;
		}
	}	
    }
    
    fclose($file); // Cierra el archivo después de terminar de usarlo


    if ($emailExists) {
        echo "Usted ya ha respondido la encuesta.";
    } else {
    	// Abrir el archivo para escribir
        $fileHandle = fopen("registro.txt", "a");
        fwrite($fileHandle, $email . PHP_EOL) ;
	fclose($fileHandle);
	$archivoEstadisticas = "estadisticas.txt";
	    $contenido = file_get_contents($archivoEstadisticas);
	    $lineas = explode(PHP_EOL, $contenido);
	    $nuevoContenido = "";
	    $equipoEncontrado = false;

	    foreach ($lineas as $linea) {
		// Verificar si la línea contiene el delimitador "="
		if (strpos($linea, "=") !== false) {
		    list($equipoActual, $votos) = explode("=", $linea);
		    $votos = intval($votos);

		    if ($equipoActual == $equipo) {
		        $votos++;
		        $equipoEncontrado = true;
		    }

		    $nuevoContenido .= "$equipoActual=$votos" . PHP_EOL;
		}
	    }

	    // Si el equipo no se encontró en el archivo de estadísticas, agregar una nueva entrada con un voto inicial de 1
	    if (!$equipoEncontrado) {
		$nuevoContenido .= "$equipo=1" . PHP_EOL;
	    }

	    file_put_contents($archivoEstadisticas, $nuevoContenido);
	    header("Location: http://10.65.4.102/");
		

	
      }  
}      

?>
