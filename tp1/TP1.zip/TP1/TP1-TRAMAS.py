archivo=open("tramas_802-15-4.log")
contenido=archivo.read()

verCorrecta = 0
verIncorrecta = 0
longCorrecta = 0
tramas = 0
escape = 0
final = False


def sumaBytes(contenido,fin,inicio):
#esta funcion nos permite sumar los bytes para hacer la suma de verificacion
    suma = 0
    for i in range(inicio, fin,2):
        suma += int(contenido[i:i+2],16)
    resultado_and = suma & 0xFF
    checksum = 0xFF - resultado_and
    return hex(checksum)


#encontramos el primer 7E y le sumamos 6 para empezar desde Tipo trama
posicion = contenido.find("7E")+6
campo = int(contenido[posicion-2:posicion],16)
#La variable campo nos permite conocer el valor del campo longitud

while final != True:
    flag = False
    #campo longitud
    campo = int(contenido[posicion-2:posicion],16)
        
    while flag == False:
        
        proxima = (contenido.find("7E", posicion, len(contenido))) - 2
        if proxima >= 0:
            #si proxima nos da un numero positivo es porque no hemos llegado al final de la cadena de texto
            if contenido[proxima:proxima+2] != "7D":
                long = (contenido.find("7E", posicion, len(contenido)))
                #calculamos la longitud que hay desde la posicion donde nos encontramos (ultimo byte del campo longitud) hasta donde se encuentra el siguiente 7E
                posCheckSum = long-2
                #posCheksum nos indica la posicion en la que empieza el campo cheksum
                longitud = ((contenido.find("7E", posicion+1, len(contenido))) - posicion - 2)/2
                #calulamos la longitud para comparar con el campo long
                flag = True
            else:
                #si antes del proximo 7E encontramos 7D es porque tenemos una secuencia de escape
                posicion = proxima+3
                #nos posicionamos en el byte siguente a la secuecia "7D7E" y contamos la secuencia de escape
                escape += 1
        else: 
            #si proxima no es un valor positivo entonces solo nos queda evaluar una trama
            long = (contenido.find("7E", posicion+1, len(contenido)))
            posCheckSum = long-2
            longitud = ((contenido.find("7E", posicion+1, len(contenido))) - posicion - 2)/2
            flag = True
            posicion = long + 6
            final = True
            
    #una vez que sabemos donde comienza y termina una trama:
    #1.aumentamos el contador de tramas       
    tramas += 1    
    
    if longitud == campo:
    #2.comparamos si longitud es igual a campo longitud
        longCorrecta += 1
        #2.Verificamos si se cumple el checksum
        checkSum = sumaBytes(contenido, long-2, posicion)
        if int(checkSum,16) == int(contenido[posCheckSum:posCheckSum+2],16):
            verCorrecta += 1
        else: 
            verIncorrecta += 1
   
    posicion = long + 6
    #actualizamos la posicion para analizar las siguiente trama 


print("Tramas totales:", tramas)
print("Tramas con longitud correcta:", longCorrecta)
print("Tramas con longitud incorrecta:", tramas - longCorrecta)
print("Tramas con longitud correcta y checksum correcto:", verCorrecta)
print("Tramas con longitud correcta y checksum incorrecto:", verIncorrecta)
print("Tramas con secuencia de escape:", escape)

