#sockets UDP

import threading
import socket

#pedimos nombre de usuario
usuario = input("Ingrese nombre de usuario: ")
#creamos el objeto
objeto_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)  
#af nos indica que usa el protocolo IPv4
#dgram es del tipo datagramas
objeto_socket.bind(('',60000)) #enlazamos en el puerto 60.000 las interfaces disponibles
objeto_socket.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST,1)
#setsock nos permite establecer opciones
#sol nos dice el nivel al que se va a aplicar el setsock (q aca es propiedades generales del socket)
#broadcast permite que se envie paquetes de difusion en la red
print("El usuario ",usuario," se ha unido a la conversacion")

flag = True
def enviar():
    global objeto_socket
    global flag
    while flag:
        dato = input("Ingrese el mensaje:")
        buffer_envio = usuario + ":" + dato
        objeto_socket.sendto(buffer_envio.encode(), ("10.65.4.255", 60000))
        if dato == "exit":
            flag = False

def recibir():
    global objeto_socket
    global flag
    while flag:
        buffer = objeto_socket.recvfrom(1024) #recibe datos (1024 tamaño maximo)
        dato_recibido = buffer[0].decode() #hace legible el dato recibido del buffer
        ip = buffer[1]
        mensaje = "Usuario (" + ip[0] + ") dice :", dato_recibido
        if dato_recibido[:-6] == ":nuevo": 
            print("El usuario " + dato_recibido[:-6] + " se ha unido a la conversacion")
        elif dato_recibido[:-5] == ":exit":  
            print("El usuario " + dato_recibido[:-5] + ip[0] + " ha abandonado la conversacion")
        else:
            print(mensaje)
        
#manejamos el hilo
hilo1 = threading.Thread(target = enviar)
hilo1.start()  #ejecutamos el hilo
hilo2 = threading.Thread(target = recibir)
hilo2.start()
