#sockets TCP
#cliente

import threading
import socket

usuario = input("Ingrese su nombre de usuario: ")
socket_cliente = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
socket_cliente.connect(('10.65.4.232',60000))
print("Conectado")

flag = True
def send():
    global flag
    global socket_cliente
    while flag:
        mensaje = input("Ingrese el mensaje: ")
        print("")
        dato = usuario + ":" + mensaje
        socket_cliente.send(dato.encode())

        if mensaje == "exit":
            flag = False

def receive():
    global flag
    global socket_cliente
    print("Conectado con: 10.65.4.232")
    while flag:
        mensaje = socket_cliente.recv(1024).decode('utf-8')
        if mensaje == "exit":
            socket_cliente.close()
            flag = False
        elif len(mensaje) != 0:
            print("")
            print("Usuario dice: " + mensaje)

hilo1 = threading.Thread(target = send)
hilo1.start()
hilo2 = threading.Thread(target = receive)
hilo2.start()
